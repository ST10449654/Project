/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.poepart1;

import javax.swing.JOptionPane;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class TaskTest {
  
    private String[] taskName;
    private int [] taskNumber;
    private Task tasks;
    
   
    
    @Before
    public void setUp() {
      Task create_task = new Task(); 
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of AddTasks method, of class Task.
     */
    @Test
    public void testAddTasks() {
     
     boolean result = Task.

    }
}